const config = {
    width: 640,
    height: 360,
    parent: "container",
    type: Phaser.AUTO,
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    physics: {
        default: "arcade",
        arcade: {
            gravity: {
                y: 900
            },
            debug: false
        }
    }
}

// Variables globales
let monedaAtk = null;
let tiempoAtaque1 = 0;
let tiempoAtaque2 = 0;
let jugador1, jugador2, cursors, keys;
let textoVidas1, textoVidas2;
let textoGanador = null;
let juegoTerminado = false;

// URL de la API - USA LA RUTA CORRECTA PARA TU DOCKER
const API_BASE = window.location.hostname === 'localhost' ? 'http://localhost:3000' : '/api';

// Sistema de puntuaciones
const PUNTUACIONES = {
    GANADOR: 100,
    PERDEDOR: -50
};

function preload(){
    this.load.image("jugador1", "./assets/img/jugador1.png");
    this.load.image("jugador2", "./assets/img/jugador2.png");
    this.load.image("jugadorAtk", "./assets/img/jugadorAtk.png");
    this.load.image("activarAtk", "./assets/img/activarAtk.png");
}

function create(){
    juegoTerminado = false;
    
    // Crear jugadores 
    jugador1 = this.physics.add.image(100, 100, "jugador1");
    jugador1.setScale(0.10);
    jugador1.setOrigin(0.5, 0.5);
    jugador1.setCollideWorldBounds(true);
    jugador1.setData('atacando', false);
    jugador1.setData('vidas', 3);
    jugador1.setData('invulnerable', false);
    jugador1.body.setSize(jugador1.width * 0.5, jugador1.height * 0.5);
    
    jugador2 = this.physics.add.image(500, 100, "jugador2");
    jugador2.setScale(0.10);
    jugador2.setOrigin(0.5, 0.5);
    jugador2.setCollideWorldBounds(true);
    jugador2.setData('atacando', false);
    jugador2.setData('vidas', 3);
    jugador2.setData('invulnerable', false);
    jugador2.body.setSize(jugador2.width * 0.5, jugador2.height * 0.5);

    // Controles
    cursors = this.input.keyboard.createCursorKeys();
    keys = this.input.keyboard.addKeys('W,A,S,D,SPACE');

    // Crear textos de UI simples
    crearUI.call(this);

    // Sistema de monedas
    this.time.addEvent({
        delay: 10000,
        callback: () => {
            crearMoneda.call(this);
        },
        loop: true
    });
    
    crearMoneda.call(this);

    // Overlap entre jugadores 
    this.physics.add.overlap(jugador1, jugador2, () => {
        if (textoGanador || juegoTerminado) return;
        
        const jugador1Atacando = jugador1.getData('atacando');
        const jugador2Atacando = jugador2.getData('atacando');
        const jugador1Invulnerable = jugador1.getData('invulnerable');
        const jugador2Invulnerable = jugador2.getData('invulnerable');
        
        if (jugador1Atacando && !jugador2Atacando && !jugador2Invulnerable) {
            reducirVida.call(this, jugador2, jugador1);
        }
        else if (jugador2Atacando && !jugador1Atacando && !jugador1Invulnerable) {
            reducirVida.call(this, jugador1, jugador2);
        }
    });
}

function update(time, delta){
    // Si ya hay ganador, no hacer nada
    if (textoGanador || juegoTerminado) return;

    // Actualizar textos de UI
    actualizarUI.call(this);

    // Movimiento horizontal Jugador 1 (WASD) - SOLO si existe
    if (jugador1 && jugador1.active) {
        if (keys.A.isDown) {
            jugador1.setVelocityX(-300);
            jugador1.flipX = false;
        } else if (keys.D.isDown) {
            jugador1.setVelocityX(300);
            jugador1.flipX = true;
        } else {
            jugador1.setVelocityX(0);
        }

        // SALTO SIN LÍMITE - Jugador 1 (W o SPACE)
        if (keys.W.isDown || keys.SPACE.isDown) {
            jugador1.setVelocityY(-400);
        }

        // Actualizar ataque Jugador 1 (4 segundos)
        if (jugador1.getData('atacando')) {
            tiempoAtaque1 -= delta;
            if (tiempoAtaque1 <= 0) {
                jugador1.setTexture("jugador1");
                jugador1.setData('atacando', false);
            }
        }
    }

    // Movimiento horizontal Jugador 2 (FLECHAS) - SOLO si existe
    if (jugador2 && jugador2.active) {
        if (cursors.left.isDown) {
            jugador2.setVelocityX(-300);
            jugador2.flipX = false;
        } else if (cursors.right.isDown) {
            jugador2.setVelocityX(300);
            jugador2.flipX = true;
        } else {
            jugador2.setVelocityX(0);
        }

        // SALTO SIN LÍMITE - Jugador 2 (FLECHA ARRIBA)
        if (cursors.up.isDown) {
            jugador2.setVelocityY(-400);
        }

        // Actualizar ataque Jugador 2 (4 segundos)
        if (jugador2.getData('atacando')) {
            tiempoAtaque2 -= delta;
            if (tiempoAtaque2 <= 0) {
                jugador2.setTexture("jugador2");
                jugador2.setData('atacando', false);
            }
        }
    }

    // Verificar si hay ganador (cuando un jugador es null)
    if (!jugador1 && jugador2 && !textoGanador && !juegoTerminado) {
        finalizarJuego.call(this, "¡JUGADOR 2 GANA!", "Jugador2", "Jugador1");
    } else if (!jugador2 && jugador1 && !textoGanador && !juegoTerminado) {
        finalizarJuego.call(this, "¡JUGADOR 1 GANA!", "Jugador1", "Jugador2");
    }
}

// FUNCIÓN: Crear interfaz de usuario simple
function crearUI() {
    const estilo = {
        fontSize: '32px',
        fill: '#fff',
        backgroundColor: '#000',
        padding: { x: 15, y: 10 }
    };

    // Jugador 1 - arriba izquierda (solo número)
    textoVidas1 = this.add.text(30, 30, '3', estilo);

    // Jugador 2 - arriba derecha (solo número)
    textoVidas2 = this.add.text(config.width - 60, 30, '3', estilo);
}

// FUNCIÓN: Actualizar interfaz de usuario
function actualizarUI() {
    // Actualizar Jugador 1
    if (jugador1 && jugador1.active) {
        textoVidas1.setText(`${jugador1.getData('vidas')}`);
    } else {
        textoVidas1.setText('0');
    }

    // Actualizar Jugador 2
    if (jugador2 && jugador2.active) {
        textoVidas2.setText(`${jugador2.getData('vidas')}`);
    } else {
        textoVidas2.setText('0');
    }
}

function crearMoneda() {
    if (textoGanador || juegoTerminado) return;

    if (monedaAtk) {
        monedaAtk.destroy();
    }
    
    const x = Phaser.Math.Between(50, config.width - 50);
    const y = Phaser.Math.Between(50, config.height - 50);
    
    monedaAtk = this.physics.add.image(x, y, "activarAtk");
    monedaAtk.setScale(0.05);
    monedaAtk.setOrigin(0.5, 0.5);
    monedaAtk.body.setAllowGravity(false);
    monedaAtk.body.setSize(monedaAtk.width * 0.4, monedaAtk.height * 0.4);

    this.physics.add.overlap(jugador1, monedaAtk, () => {
        if (monedaAtk && monedaAtk.active && jugador1 && jugador1.active && !textoGanador && !juegoTerminado) {
            jugador1.setTexture("jugadorAtk");
            jugador1.setData('atacando', true);
            tiempoAtaque1 = 4000;
            monedaAtk.destroy();
            monedaAtk = null;
        }
    });

    this.physics.add.overlap(jugador2, monedaAtk, () => {
        if (monedaAtk && monedaAtk.active && jugador2 && jugador2.active && !textoGanador && !juegoTerminado) {
            jugador2.setTexture("jugadorAtk");
            jugador2.setData('atacando', true);
            tiempoAtaque2 = 4000;
            monedaAtk.destroy();
            monedaAtk = null;
        }
    });
}

function reducirVida(jugadorGolpeado, jugadorAtacante) {
    if (!jugadorGolpeado || !jugadorGolpeado.active || textoGanador || juegoTerminado) return;
    
    let vidas = jugadorGolpeado.getData('vidas');
    vidas--;
    jugadorGolpeado.setData('vidas', vidas);
    
    console.log(`Jugador ${jugadorGolpeado === jugador1 ? '1' : '2'} golpeado! Vidas restantes: ${vidas}`);
    
    aplicarInvulnerabilidad.call(this, jugadorGolpeado);
    efectoDano.call(this, jugadorGolpeado);
    
    if (vidas <= 0) {
        eliminarJugador.call(this, jugadorGolpeado);
    }
}

function aplicarInvulnerabilidad(jugador) {
    if (!jugador || !jugador.active || textoGanador || juegoTerminado) return;
    
    jugador.setData('invulnerable', true);
    
    this.time.delayedCall(2000, () => {
        if (jugador.active && !textoGanador && !juegoTerminado) {
            jugador.setData('invulnerable', false);
            jugador.setAlpha(1);
        }
    });
}

function efectoDano(jugador) {
    if (!jugador || !jugador.active || textoGanador || juegoTerminado) return;
    
    let contador = 0;
    const timer = this.time.addEvent({
        delay: 200,
        callback: () => {
            if (jugador.active && !textoGanador && !juegoTerminado) {
                jugador.setAlpha(jugador.alpha === 1 ? 0.4 : 1);
                contador++;
                if (contador >= 6) {
                    timer.remove();
                    if (jugador.active && !textoGanador && !juegoTerminado) {
                        jugador.setAlpha(1);
                    }
                }
            } else {
                timer.remove();
            }
        },
        callbackScope: this,
        loop: true
    });
}

function eliminarJugador(jugador) {
    if (!jugador || !jugador.active || textoGanador || juegoTerminado) return;
    
    console.log(`Jugador ${jugador === jugador1 ? '1' : '2'} ELIMINADO!`);
    
    jugador.destroy();
    
    if (jugador === jugador1) {
        jugador1 = null;
    } else {
        jugador2 = null;
    }
}

// FUNCIÓN: Finalizar juego y actualizar puntuaciones
function finalizarJuego(mensaje, ganador, perdedor) {
    juegoTerminado = true;
    mostrarGanador.call(this, mensaje);
    actualizarPuntuaciones(ganador, perdedor);
}

// FUNCIÓN: Mostrar ganador
function mostrarGanador(texto) {
    const estilo = {
        fontSize: '48px',
        fill: '#fff',
        backgroundColor: '#000',
        padding: { x: 30, y: 20 },
        stroke: '#ffd700',
        strokeThickness: 4
    };

    textoGanador = this.add.text(config.width / 2, config.height / 2, texto, estilo);
    textoGanador.setOrigin(0.5);

    // Efecto de animación
    textoGanador.setScale(0);
    this.tweens.add({
        targets: textoGanador,
        scaleX: 1,
        scaleY: 1,
        duration: 1000,
        ease: 'Elastic.out'
    });

    console.log(texto);
}

// FUNCIÓN: Actualizar puntuaciones en la API
async function actualizarPuntuaciones(ganador, perdedor) {
    try {
        console.log(`🏆 Actualizando puntuaciones...`);
        console.log(`   ${ganador}: +${PUNTUACIONES.GANADOR} puntos`);
        console.log(`   ${perdedor}: ${PUNTUACIONES.PERDEDOR} puntos`);
        
        // Actualizar puntuación del ganador (+100)
        await actualizarPuntuacionJugador(ganador, PUNTUACIONES.GANADOR);
        
        // Actualizar puntuación del perdedor (-50)
        await actualizarPuntuacionJugador(perdedor, PUNTUACIONES.PERDEDOR);
        
        console.log('✅ Puntuaciones actualizadas correctamente');
        
    } catch (error) {
        console.error('❌ Error al actualizar puntuaciones:', error);
        mostrarErrorPuntuacion.call(this, error.message);
    }
}

// FUNCIÓN: Actualizar puntuación individual
async function actualizarPuntuacionJugador(jugador, puntos) {
    try {
        const response = await fetch(`${API_BASE}/scores/player`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                player_name: jugador,
                score: puntos
            })
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        console.log(`✅ ${jugador}: ${result.operation} - ${puntos > 0 ? '+' : ''}${puntos} puntos`);
        return result;
        
    } catch (error) {
        console.error(`❌ Error al actualizar puntuación para ${jugador}:`, error);
        throw error;
    }
}
const game = new Phaser.Game(config);