﻿const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors'); // ← AÑADIR ESTO

const app = express();


app.use(cors({
    origin: ['https://localhost', 'http://localhost', 'https://127.0.0.1'],
    credentials: true
}));

app.use(express.json());

// Configuración de la base de datos
const dbConfig = {
    host: process.env.DB_HOST || 'mysql',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'admin',
    database: process.env.DB_NAME || 'game_db',
    port: process.env.DB_PORT || 3306
};

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'API funcionando' });
});

// Obtener todas las puntuaciones
app.get('/scores', async (req, res) => {
    try {
        const connection = await mysql.createConnection(dbConfig);
        const [rows] = await connection.execute('SELECT * FROM scores ORDER BY score DESC');
        await connection.end();
        res.json(rows);
    } catch (error) {
        console.error('Error obteniendo puntuaciones:', error);
        res.status(500).json({ error: error.message });
    }
});

// Crear nueva puntuación
app.post('/scores', async (req, res) => {
    try {
        const { player_name, score } = req.body;
        const connection = await mysql.createConnection(dbConfig);
        const [result] = await connection.execute(
            'INSERT INTO scores (player_name, score) VALUES (?, ?)',
            [player_name, score]
        );
        await connection.end();
        res.json({ success: true, id: result.insertId });
    } catch (error) {
        console.error('Error creando puntuación:', error);
        res.status(500).json({ error: error.message });
    }
});

// Eliminar puntuación por ID
app.delete('/scores/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        if (isNaN(id) || id <= 0) {
            return res.status(400).json({ 
                success: false, 
                error: 'ID inválido' 
            });
        }

        const connection = await mysql.createConnection(dbConfig);
        
        // Verificar si existe
        const [checkRows] = await connection.execute(
            'SELECT * FROM scores WHERE id = ?',
            [id]
        );

        if (checkRows.length === 0) {
            await connection.end();
            return res.status(404).json({ 
                success: false, 
                error: 'Puntuación no encontrada' 
            });
        }

        // Eliminar
        const [result] = await connection.execute(
            'DELETE FROM scores WHERE id = ?',
            [id]
        );
        
        await connection.end();
        
        res.json({ 
            success: true, 
            message: 'Puntuación eliminada',
            deletedId: parseInt(id)
        });
        
    } catch (error) {
        console.error('Error eliminando puntuación:', error.message);
        res.status(500).json({ 
            success: false, 
            error: 'Error del servidor' 
        });
    }
});

// ACTUALIZAR O CREAR PUNTUACIÓN - VERSIÓN SIMPLIFICADA Y ROBUSTA
app.put('/scores/player', async (req, res) => {
    let connection;
    try {
        const { player_name, score } = req.body;
        
        console.log(`🎯 PUT /scores/player: ${player_name} -> ${score}`);
        
        if (!player_name || score === undefined) {
            return res.status(400).json({ 
                success: false, 
                error: 'Faltan player_name o score' 
            });
        }

        connection = await mysql.createConnection(dbConfig);
        
        // INTENTAR ACTUALIZAR primero (si existe)
        const [updateResult] = await connection.execute(
            'UPDATE scores SET score = score + ? WHERE player_name = ?',
            [score, player_name]
        );
        
        // Si se actualizó (existe), retornar éxito
        if (updateResult.affectedRows > 0) {
            // Obtener la nueva puntuación
            const [current] = await connection.execute(
                'SELECT score FROM scores WHERE player_name = ?',
                [player_name]
            );
            
            await connection.end();
            console.log(`✅ ${player_name} ACTUALIZADO: +${score} = ${current[0].score}`);
            
            return res.json({ 
                success: true, 
                message: 'Puntuación actualizada',
                player_name: player_name,
                operation: 'update',
                new_score: current[0].score,
                points_added: score
            });
        }
        
        // Si no se actualizó (no existe), CREAR
        console.log(`🆕 ${player_name} no existe, CREANDO...`);
        const [insertResult] = await connection.execute(
            'INSERT INTO scores (player_name, score) VALUES (?, ?)',
            [player_name, score]
        );
        
        await connection.end();
        console.log(`✅ ${player_name} CREADO con ${score} puntos`);
        
        res.json({ 
            success: true, 
            message: 'Puntuación creada',
            player_name: player_name,
            operation: 'create',
            new_score: score,
            points_added: score
        });
        
    } catch (error) {
        if (connection) await connection.end();
        console.error('❌ Error en /scores/player:', error.message);
        res.status(500).json({ 
            success: false, 
            error: 'Error del servidor' 
        });
    }
});

// Endpoint adicional: Obtener puntuación específica de jugador
app.get('/scores/player/:name', async (req, res) => {
    try {
        const player_name = req.params.name;
        const connection = await mysql.createConnection(dbConfig);
        
        const [rows] = await connection.execute(
            'SELECT * FROM scores WHERE player_name = ?',
            [player_name]
        );
        
        await connection.end();
        
        if (rows.length === 0) {
            return res.json({ 
                exists: false,
                player_name: player_name
            });
        }
        
        res.json({ 
            exists: true,
            player_name: player_name,
            score: rows[0].score,
            id: rows[0].id
        });
        
    } catch (error) {
        console.error('Error obteniendo jugador:', error);
        res.status(500).json({ error: error.message });
    }
});

// Iniciar servidor
app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 Servidor ejecutándose en puerto ${port}`);
    console.log(`📊 Base de datos: ${dbConfig.host}:${dbConfig.port}/${dbConfig.database}`);
});