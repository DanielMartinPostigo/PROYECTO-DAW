﻿const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Configuración de la base de datos desde variables de entorno
const dbConfig = {
    host: process.env.DB_HOST || 'mysql',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'admin',
    database: process.env.DB_NAME || 'game_db',
    port: process.env.DB_PORT || 3306
};

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'API funcionando' });
});

// Get scores
app.get('/scores', async (req, res) => {
    try {
        const connection = await mysql.createConnection(dbConfig);
        const [rows] = await connection.execute('SELECT * FROM scores ORDER BY score DESC');
        await connection.end();
        res.json(rows);
    } catch (error) {
        console.error('Error getting scores:', error);
        res.status(500).json({ error: error.message });
    }
});

// Add score
app.post('/scores', async (req, res) => {
    try {
        const { player_name, score } = req.body;
        const connection = await mysql.createConnection(dbConfig);
        const [result] = await connection.execute(
            'INSERT INTO scores (player_name, score) VALUES (?, ?)',
            [player_name, score]
        );
        await connection.end();
        res.json({ success: true, id: result.insertId });
    } catch (error) {
        console.error('Error adding score:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /scores/:id - Eliminar una puntuación por ID
app.delete('/scores/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        console.log(`[DELETE] Solicitando eliminar puntuación ID: ${id}`);
        
        // Validar que el ID sea un número
        if (isNaN(id) || id <= 0) {
            return res.status(400).json({ 
                success: false, 
                error: 'ID inválido' 
            });
        }

        const connection = await mysql.createConnection(dbConfig);
        
        // Verificar si existe la puntuación
        const [checkRows] = await connection.execute(
            'SELECT * FROM scores WHERE id = ?',
            [id]
        );

        if (checkRows.length === 0) {
            await connection.end();
            console.log(`⚠️ Puntuación ID: ${id} no encontrada`);
            return res.status(404).json({ 
                success: false, 
                error: 'Puntuación no encontrada' 
            });
        }

        // Eliminar la puntuación
        const [result] = await connection.execute(
            'DELETE FROM scores WHERE id = ?',
            [id]
        );
        
        await connection.end();
        
        console.log(`✅ Puntuación ID: ${id} eliminada correctamente`);
        res.json({ 
            success: true, 
            message: 'Puntuación eliminada correctamente',
            deletedId: parseInt(id),
            affectedRows: result.affectedRows
        });
        
    } catch (error) {
        console.error('❌ Error al eliminar puntuación:', error.message);
        res.status(500).json({ 
            success: false, 
            error: 'Error interno del servidor: ' + error.message 
        });
    }
});

// PUT /scores/player - Crear o actualizar puntuación de jugador (VERSIÓN CORREGIDA)
app.put('/scores/player', async (req, res) => {
    try {
        const { player_name, score } = req.body;
        
        console.log(`🔍 PUT /scores/player recibido:`, { player_name, score });
        
        if (!player_name || score === undefined) {
            return res.status(400).json({ 
                success: false, 
                error: 'player_name y score son requeridos' 
            });
        }

        const connection = await mysql.createConnection(dbConfig);
        
        // PRIMERO: Verificar si existe el jugador
        const [existing] = await connection.execute(
            'SELECT id, score FROM scores WHERE player_name = ?',
            [player_name]
        );

        let result;
        let operation;
        let currentScore;
        
        if (existing.length === 0) {
            // CREAR: Si no existe, insertar nuevo jugador
            console.log(`🆕 ${player_name} no existe, CREANDO con ${score} puntos`);
            [result] = await connection.execute(
                'INSERT INTO scores (player_name, score) VALUES (?, ?)',
                [player_name, score]
            );
            operation = 'create';
            currentScore = score;
        } else {
            // ACTUALIZAR: Si existe, sumar a la puntuación actual
            currentScore = existing[0].score;
            const nuevaPuntuacion = currentScore + score;
            console.log(`🔄 ${player_name} existe: ${currentScore} + ${score} = ${nuevaPuntuacion}`);
            
            [result] = await connection.execute(
                'UPDATE scores SET score = ? WHERE player_name = ?',
                [nuevaPuntuacion, player_name]
            );
            operation = 'update';
            currentScore = nuevaPuntuacion;
        }
        
        await connection.end();
        
        console.log(`✅ ${player_name}: ${operation} exitoso - Puntuación: ${currentScore}`);
        
        res.json({ 
            success: true, 
            message: `Puntuación ${operation === 'update' ? 'actualizada' : 'creada'}`,
            player_name: player_name,
            operation: operation,
            current_score: currentScore,
            affectedRows: result.affectedRows
        });
        
    } catch (error) {
        console.error('❌ Error en /scores/player:', error.message);
        res.status(500).json({ 
            success: false, 
            error: 'Error interno del servidor: ' + error.message 
        });
    }
});

app.listen(port, '0.0.0.0', () => {
    console.log('Server running on port ' + port);
});